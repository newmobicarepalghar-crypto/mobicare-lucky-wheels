
import { db } from './firebase-config.js';
const spinBtn = document.getElementById('spinBtn');
spinBtn.addEventListener('click', () => {
    alert('Spinning...');
    // Firebase save logic here
});
